#!/usr/bin/env python3
"""
VoIP Bot - Multi-User Version with Error Handling
Identity Generator with Auto Email Monitoring
"""
import telebot
from telebot import types
import requests
import time
import random
import string
import re
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, List
import threading
import queue
import json

# Bot Configuration
BOT_TOKEN = "8222997114:AAFy0fE97lzDqoRuwwwP8LYFIs8r8jLBE6g"

# Initialize bot with error handling
bot = telebot.TeleBot(BOT_TOKEN)

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Global variables with thread safety
user_sessions = {}
email_monitors = {}
message_queue = queue.Queue()
active_users = set()
session_lock = threading.Lock()

# Rate limiting
user_requests = {}
RATE_LIMIT_WINDOW = 30  # seconds
RATE_LIMIT_MAX = 15  # max requests per window

# TempMail API with retry logic and multiple providers
class TempMailAPI:
    def __init__(self):
        self.base_urls = [
            "https://api.tempmail.lol",
            "https://api.1secmail.com",
            "https://api.tempmail.org"
        ]
        self.max_retries = 3
        self.timeout = 30
        self.current_provider = 0
    
    def generate_email(self):
        for attempt in range(self.max_retries):
            try:
                # Try different API endpoints
                for provider_idx in range(len(self.base_urls)):
                    try:
                        base_url = self.base_urls[provider_idx]
                        response = requests.get(f"{base_url}/generate", timeout=self.timeout)
                        
                        if response.status_code == 200:
                            data = response.json()
                            if data and 'address' in data and 'token' in data:
                                self.current_provider = provider_idx
                                logger.info(f"Using provider {provider_idx}: {base_url}")
                                return data
                        
                        logger.warning(f"Provider {provider_idx} failed with status {response.status_code}")
                        
                    except Exception as e:
                        logger.warning(f"Provider {provider_idx} error: {e}")
                        continue
                
                logger.warning(f"Email generation attempt {attempt + 1} failed for all providers")
                time.sleep(3)
                
            except Exception as e:
                logger.error(f"Email generation error (attempt {attempt + 1}): {e}")
                time.sleep(3)
        return None
    
    def check_inbox(self, token):
        for attempt in range(self.max_retries):
            try:
                # Try current provider first, then others
                providers_to_try = [self.current_provider] + [i for i in range(len(self.base_urls)) if i != self.current_provider]
                
                for provider_idx in providers_to_try:
                    try:
                        base_url = self.base_urls[provider_idx]
                        response = requests.get(f"{base_url}/auth/{token}", timeout=self.timeout)
                        
                        if response.status_code == 200:
                            data = response.json()
                            if isinstance(data, list):
                                return data
                            elif isinstance(data, dict):
                                # Try different possible keys for email list
                                for key in ['emails', 'mail', 'messages', 'data', 'email', 'result']:
                                    if key in data and isinstance(data[key], list):
                                        return data[key]
                                # If no list found, return empty list
                                return []
                            else:
                                return []
                        elif response.status_code == 404:
                            return []  # No emails
                        elif response.status_code == 401:
                            logger.warning(f"Token expired for provider {provider_idx}")
                            return []
                        
                        logger.warning(f"Provider {provider_idx} returned status {response.status_code}")
                        
                    except Exception as e:
                        logger.warning(f"Provider {provider_idx} error: {e}")
                        continue
                
                logger.warning(f"Inbox check attempt {attempt + 1} failed for all providers")
                time.sleep(2)
                
            except Exception as e:
                logger.error(f"Inbox check error (attempt {attempt + 1}): {e}")
                time.sleep(2)
        return []

def rate_limit_check(user_id):
    """Check if user is within rate limits"""
    now = datetime.now()
    if user_id not in user_requests:
        user_requests[user_id] = []
    
    # Remove old requests outside the window
    user_requests[user_id] = [
        req_time for req_time in user_requests[user_id] 
        if now - req_time < timedelta(seconds=RATE_LIMIT_WINDOW)
    ]
    
    # Check if under limit
    if len(user_requests[user_id]) >= RATE_LIMIT_MAX:
        return False
    
    # Add current request
    user_requests[user_id].append(now)
    return True

def get_user_session(user_id):
    """Get or create user session with thread safety"""
    with session_lock:
        if user_id not in user_sessions:
            user_sessions[user_id] = {
                'email': None,
                'token': None,
                'created_at': None,
                'last_email_count': 0,
                'error_count': 0,
                'cached_emails': [],
                'last_activity': datetime.now(),
                'user_name': None,
                'password': None,
                'otp_codes': [],
                'is_active': False
            }
        return user_sessions[user_id]

def generate_random_name():
    first_names = ['Alex', 'Jordan', 'Casey', 'Taylor', 'Morgan', 'Riley', 'Avery', 'Quinn', 'Sage', 'River', 'Blake', 'Cameron', 'Drew', 'Emery', 'Finley']
    last_names = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez', 'Anderson', 'Taylor', 'Thomas', 'Hernandez', 'Moore']
    return f"{random.choice(first_names)} {random.choice(last_names)}"

def generate_password():
    chars = string.ascii_letters + string.digits
    password = ''.join(random.choice(chars) for _ in range(10))
    # Ensure at least one uppercase, one lowercase, one digit
    if not any(c.isupper() for c in password):
        password = password[:-1] + random.choice(string.ascii_uppercase)
    if not any(c.islower() for c in password):
        password = password[:-1] + random.choice(string.ascii_lowercase)
    if not any(c.isdigit() for c in password):
        password = password[:-1] + random.choice(string.digits)
    return password

def escape_html(text):
    return str(text).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

def format_user_info_display(session):
    name = session.get('user_name', 'Not Generated')
    email = session.get('email', 'Not Generated')
    password = session.get('password', 'Not Generated')
    
    return f"""👤 <b>USER INFO</b>

<b>Name:</b> <code>{name}</code>
<b>Email:</b> <code>{email}</code>
<b>Password:</b> <code>{password}</code>"""

def extract_confirm_link(email):
    # Try multiple fields for email content
    body_fields = ['body', 'content', 'text', 'html', 'message']
    body = ""
    
    for field in body_fields:
        if field in email and email[field]:
            body = str(email[field])
            break
    
    if not body:
        return ""
    
    # More comprehensive link extraction
    link_patterns = [
        r'https?://[^\s<>"\'\)]+',  # Basic URL pattern
        r'href=["\']([^"\']+)["\']',  # HTML href attributes
        r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>',  # Full anchor tags
    ]
    
    links = []
    for pattern in link_patterns:
        matches = re.findall(pattern, body, re.IGNORECASE)
        links.extend(matches)
    
    # Remove duplicates and clean up
    links = list(set(links))
    links = [link.strip() for link in links if link.strip()]
    
    confirm_keywords = [
        'confirm', 'verify', 'activation', 'complete-registration', 
        'activate', 'validate', 'approve', 'accept', 'enable',
        'registration', 'signup', 'sign-up', 'register', 'setup',
        'welcome', 'activate-account', 'verify-email', 'confirm-email'
    ]
    
    for link in links:
        link_lower = link.lower()
        for keyword in confirm_keywords:
            if keyword in link_lower:
                return link
    
    # If no confirm links found, return the first valid link
    if links:
        return links[0]
    
    return ""

def extract_otp_codes(text):
    if not text:
        return []
    
    # Convert to string and clean up
    text = str(text).replace('\n', ' ').replace('\r', ' ')
    
    patterns = [
        # Direct OTP patterns - numeric codes
        r'OTP[:\s]*(\d{4,8})',
        r'Code[:\s]*(\d{4,8})',
        r'Verification[:\s]*(\d{4,8})',
        r'Token[:\s]*(\d{4,8})',
        r'PIN[:\s]*(\d{4,8})',
        r'Verification\s+Code[:\s]*(\d{4,8})',
        r'Activation\s+Code[:\s]*(\d{4,8})',
        r'Confirmation\s+Code[:\s]*(\d{4,8})',
        
        # Direct OTP patterns - alphanumeric codes
        r'OTP[:\s]*([a-zA-Z0-9]{8,32})',
        r'Code[:\s]*([a-zA-Z0-9]{8,32})',
        r'Verification[:\s]*([a-zA-Z0-9]{8,32})',
        r'Token[:\s]*([a-zA-Z0-9]{8,32})',
        r'PIN[:\s]*([a-zA-Z0-9]{8,32})',
        r'Verification\s+Code[:\s]*([a-zA-Z0-9]{8,32})',
        r'Activation\s+Code[:\s]*([a-zA-Z0-9]{8,32})',
        r'Confirmation\s+Code[:\s]*([a-zA-Z0-9]{8,32})',
        
        # Generic patterns - numeric codes
        r'\b(\d{6})\b',  # 6-digit codes (most common)
        r'\b(\d{4})\b',  # 4-digit codes
        r'\b(\d{5})\b',  # 5-digit codes
        r'\b(\d{8})\b',  # 8-digit codes
        
        # Generic patterns - alphanumeric codes
        r'\b([a-zA-Z0-9]{12,20})\b',  # 12-20 character alphanumeric codes
        r'\b([a-zA-Z0-9]{16})\b',     # 16 character codes (like your example)
        r'\b([a-zA-Z0-9]{8,24})\b',   # 8-24 character codes
        
        # Pattern with context - numeric
        r'your\s+(?:verification\s+)?code\s+is[:\s]*(\d{4,8})',
        r'enter\s+(?:the\s+)?code[:\s]*(\d{4,8})',
        r'use\s+(?:this\s+)?code[:\s]*(\d{4,8})',
        r'verification\s+code[:\s]*(\d{4,8})',
        r'activation\s+code[:\s]*(\d{4,8})',
        
        # Pattern with context - alphanumeric
        r'your\s+(?:verification\s+)?code\s+is[:\s]*([a-zA-Z0-9]{8,32})',
        r'enter\s+(?:the\s+)?code[:\s]*([a-zA-Z0-9]{8,32})',
        r'use\s+(?:this\s+)?code[:\s]*([a-zA-Z0-9]{8,32})',
        r'verification\s+code[:\s]*([a-zA-Z0-9]{8,32})',
        r'activation\s+code[:\s]*([a-zA-Z0-9]{8,32})',
    ]
    
    codes = []
    for pattern in patterns:
        matches = re.findall(pattern, text, re.IGNORECASE)
        codes.extend(matches)
    
    # Filter out common false positives
    filtered_codes = []
    for code in codes:
        code_str = str(code).strip()
        
        # Skip if it's too short or too long
        if len(code_str) < 4 or len(code_str) > 32:
            continue
            
        # Skip if it looks like a date/year (for numeric codes)
        if code_str.isdigit():
            if (code_str.startswith('19') or code_str.startswith('20')) and len(code_str) >= 4:
                continue
            if code_str.startswith('0') and len(code_str) != 6:
                continue
        
        # Skip if it's all the same character
        if len(set(code_str)) == 1:
            continue
            
        # Skip if it's a common word or pattern
        common_words = ['password', 'username', 'email', 'phone', 'address', 'name', 'user', 'verification', 'confirmation', 'activation']
        if code_str.lower() in common_words:
            continue
            
        filtered_codes.append(code_str)
    
    return list(set(filtered_codes))

def format_new_message_with_confirm_link(email, otp=None):
    sender = escape_html(str(email.get('from', 'Unknown'))[:50])
    subject = escape_html(str(email.get('subject', '[No Subject]'))[:60])
    
    if otp:
        message = f"""📩 <b>New Message</b>

<b>From:</b> <code>{sender}</code>
<b>Subject:</b> <code>{subject}</code>
<b>OTP:</b> <code>{otp}</code>"""
    else:
        message = f"""📩 <b>New Message</b>

<b>From:</b> <code>{sender}</code>
<b>Subject:</b> <code>{subject}</code>
<b>OTP:</b> <code>N/A</code>"""
    
    return message

def format_new_message_without_confirm_link(email, otp=None):
    sender = escape_html(str(email.get('from', 'Unknown'))[:50])
    subject = escape_html(str(email.get('subject', '[No Subject]'))[:60])
    
    if otp:
        message = f"""📩 <b>New Message</b>

<b>From:</b> <code>{sender}</code>
<b>Subject:</b> <code>{subject}</code>
<b>OTP:</b> <code>{otp}</code>
<b>Summary:</b> <code>No action link provided</code>"""
    else:
        message = f"""📩 <b>New Message</b>

<b>From:</b> <code>{sender}</code>
<b>Subject:</b> <code>{subject}</code>
<b>OTP:</b> <code>N/A</code>
<b>Summary:</b> <code>No action link provided</code>"""
    
    return message

def safe_send_message(user_id, text, **kwargs):
    """Send message with error handling and retry logic"""
    max_retries = 3
    for attempt in range(max_retries):
        try:
            kwargs['parse_mode'] = 'HTML'
            bot.send_message(user_id, text, **kwargs)
            return True
        except Exception as e:
            logger.error(f"Failed to send message to {user_id} (attempt {attempt + 1}): {e}")
            if attempt < max_retries - 1:
                time.sleep(2)
    return False

def message_processor():
    """Process messages from queue"""
    while True:
        try:
            message_data = message_queue.get(timeout=1)
            user_id = message_data['user_id']
            text = message_data['text']
            kwargs = message_data.get('kwargs', {})
            
            safe_send_message(user_id, text, **kwargs)
            message_queue.task_done()
        except queue.Empty:
            continue
        except Exception as e:
            logger.error(f"Message processor error: {e}")

# Start message processor thread
message_thread = threading.Thread(target=message_processor, daemon=True)
message_thread.start()

# Command handlers
@bot.message_handler(commands=['start', 'help'])
def start_command(message):
    user_id = message.from_user.id
    
    # Rate limiting
    if not rate_limit_check(user_id):
        bot.reply_to(message, "⏰ <b>Please wait a moment</b>\n\nToo many requests. Try again in a few seconds.", parse_mode='HTML')
        return
    
    welcome_message = """
<b>🪄 Identity Generator</b>

Generate fresh identities with auto-monitoring.

<i>Tap below to start →</i>
"""
    
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
    markup.add(types.KeyboardButton("🪄 Gen New"))
    
    try:
        bot.reply_to(message, welcome_message, reply_markup=markup, parse_mode='HTML')
    except Exception as e:
        logger.error(f"Error in start command: {e}")

@bot.message_handler(func=lambda message: message.text == "🪄 Gen New")
def gen_new_button_handler(message):
    user_id = message.from_user.id
    
    # Rate limiting
    if not rate_limit_check(user_id):
        bot.reply_to(message, "⏰ <b>Please wait a moment</b>\n\nToo many requests. Try again in a few seconds.", parse_mode='HTML')
        return
    
    session = get_user_session(user_id)
    
    try:
        # Generate new email with retry logic
        tempmail = TempMailAPI()
        result = tempmail.generate_email()
        
        if not result:
            raise ValueError("Failed to generate email after multiple attempts")
        
        # Check current inbox
        try:
            current_emails = tempmail.check_inbox(result.get('token'))
            if not isinstance(current_emails, list):
                current_emails = []
            baseline_count = len(current_emails)  # Set baseline to actual current count
            logger.info(f"Initial inbox check: {baseline_count} emails found")
        except Exception as e:
            logger.warning(f"Failed to check initial inbox: {e}")
            baseline_count = 0
            current_emails = []
        
        # Generate user info
        user_name = generate_random_name()
        password = generate_password()
        
        # Update session
        with session_lock:
            session.update({
                'email': result.get('address'),
                'token': result.get('token'),
                'created_at': datetime.now(),
                'last_email_count': baseline_count,
                'error_count': 0,
                'cached_emails': current_emails,
                'last_activity': datetime.now(),
                'user_name': user_name,
                'password': password,
                'otp_codes': [],
                'is_active': True
            })
        
        # Enable monitoring
        email_monitors[user_id] = True
        active_users.add(user_id)
        
        # Send confirmation that monitoring is active
        logger.info(f"Enabled monitoring for user {user_id} with email {result.get('address')}")
        
        # Process any existing emails immediately
        if current_emails:
            logger.info(f"User {user_id}: Processing {len(current_emails)} existing emails")
            for email in current_emails:
                try:
                    # Try multiple fields for email content
                    email_body = ""
                    for field in ['body', 'content', 'text', 'html', 'message']:
                        if field in email and email[field]:
                            email_body = str(email[field])
                            break
                    
                    if not email_body:
                        logger.warning(f"No email body found in existing email for user {user_id}")
                        continue
                    
                    otp_codes = extract_otp_codes(email_body)
                    best_otp = max(otp_codes, key=len) if otp_codes else None
                    
                    confirm_link = extract_confirm_link(email)
                    
                    if confirm_link:
                        content = format_new_message_with_confirm_link(email, best_otp)
                        markup = types.InlineKeyboardMarkup()
                        markup.add(types.InlineKeyboardButton("✅ Confirm Link", url=confirm_link))
                        
                        message_queue.put({
                            'user_id': user_id,
                            'text': content,
                            'kwargs': {'reply_markup': markup}
                        })
                    else:
                        if best_otp:
                            content = format_new_message_without_confirm_link(email, best_otp)
                        else:
                            content = format_new_message_without_confirm_link(email)
                        
                        message_queue.put({
                            'user_id': user_id,
                            'text': content
                        })
                except Exception as e:
                    logger.error(f"Error processing existing email for user {user_id}: {e}")
        
        # Format response
        user_info = format_user_info_display(session)
        success_message = f"""
{user_info}

<i>✅ Ready! Emails will arrive automatically.</i>
"""
        
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=False)
        markup.add(types.KeyboardButton("🪄 Gen New"))
        
        bot.reply_to(message, success_message, reply_markup=markup, parse_mode='HTML')
        
        logger.info(f"User {user_id} generated new identity: {user_name}")
        
    except Exception as e:
        logger.error(f"Error generating new identity for user {user_id}: {e}")
        error_message = f"❌ <b>Error generating identity</b>\n\n<code>{escape_html(str(e)[:150])}</code>"
        bot.reply_to(message, error_message, parse_mode='HTML')

@bot.message_handler(func=lambda message: message.text and "raw link" in message.text.lower())
def raw_link_handler(message):
    user_id = message.from_user.id
    session = get_user_session(user_id)
    
    if not session.get('cached_emails'):
        bot.reply_to(message, "❌ No recent emails to show links for.", parse_mode='HTML')
        return
    
    recent_email = session['cached_emails'][-1] if session['cached_emails'] else None
    if not recent_email:
        bot.reply_to(message, "❌ No recent emails found.", parse_mode='HTML')
        return
    
    body = str(recent_email.get('body', ''))
    links = re.findall(r'https?://[^\s<>"]+', body)
    
    if not links:
        bot.reply_to(message, "❌ No links found in the recent email.", parse_mode='HTML')
        return
    
    link_text = "\n".join([f"🔗 <code>{link}</code>" for link in links])
    response = f"""📩 <b>Raw Links from Recent Email</b>

{link_text}"""
    
    bot.reply_to(message, response, parse_mode='HTML')

@bot.message_handler(commands=['debug'])
def debug_command(message):
    user_id = message.from_user.id
    session = get_user_session(user_id)
    
    debug_info = f"""🔍 <b>Debug Information</b>

<b>User ID:</b> <code>{user_id}</code>
<b>Email:</b> <code>{session.get('email', 'Not set')}</code>
<b>Token:</b> <code>{session.get('token', 'Not set')[:20]}...</code>
<b>Is Active:</b> <code>{session.get('is_active', False)}</code>
<b>Monitoring:</b> <code>{email_monitors.get(user_id, False)}</code>
<b>Error Count:</b> <code>{session.get('error_count', 0)}</code>
<b>Last Email Count:</b> <code>{session.get('last_email_count', 0)}</code>
<b>Cached Emails:</b> <code>{len(session.get('cached_emails', []))}</code>
<b>Created:</b> <code>{session.get('created_at', 'Not set')}</code>
<b>Last Activity:</b> <code>{session.get('last_activity', 'Not set')}</code>

<b>Active Users:</b> <code>{len(active_users)}</code>
<b>Total Sessions:</b> <code>{len(user_sessions)}</code>"""
    
    bot.reply_to(message, debug_info, parse_mode='HTML')

@bot.message_handler(commands=['test_email'])
def test_email_command(message):
    user_id = message.from_user.id
    session = get_user_session(user_id)
    
    if not session.get('token'):
        bot.reply_to(message, "❌ No email token found. Generate a new identity first.", parse_mode='HTML')
        return
    
    try:
        tempmail = TempMailAPI()
        emails = tempmail.check_inbox(session['token'])
        
        if not isinstance(emails, list):
            emails = []
        
        response = f"""📧 <b>Email Test Results</b>

<b>Emails Found:</b> <code>{len(emails)}</code>
<b>Last Count:</b> <code>{session.get('last_email_count', 0)}</code>
<b>Status:</b> <code>API Working</code>

<i>This is a test of the email checking system.</i>"""
        
        bot.reply_to(message, response, parse_mode='HTML')
        
    except Exception as e:
        error_response = f"""❌ <b>Email Test Failed</b>

<b>Error:</b> <code>{escape_html(str(e))}</code>
<b>Status:</b> <code>API Error</code>"""
        
        bot.reply_to(message, error_response, parse_mode='HTML')

@bot.message_handler(commands=['force_check'])
def force_check_command(message):
    user_id = message.from_user.id
    session = get_user_session(user_id)
    
    if not session.get('token'):
        bot.reply_to(message, "❌ No email token found. Generate a new identity first.", parse_mode='HTML')
        return
    
    try:
        tempmail = TempMailAPI()
        emails = tempmail.check_inbox(session['token'])
        
        # Log detailed response
        logger.info(f"Force check for user {user_id}: Raw response = {emails}")
        
        if not isinstance(emails, list):
            if isinstance(emails, dict):
                logger.info(f"Response is dict with keys: {list(emails.keys())}")
                # Try to extract emails from different possible keys
                for key in ['emails', 'mail', 'messages', 'data', 'result']:
                    if key in emails:
                        logger.info(f"Found key '{key}': {emails[key]}")
                        if isinstance(emails[key], list):
                            emails = emails[key]
                            break
            else:
                logger.info(f"Response is not list or dict: {type(emails)}")
        
        current_count = len(emails) if isinstance(emails, list) else 0
        last_count = session.get('last_email_count', 0)
        
        # Update session
        with session_lock:
            session['last_email_count'] = current_count
            session['cached_emails'] = emails if isinstance(emails, list) else []
            session['last_activity'] = datetime.now()
        
        response = f"""🔍 <b>Force Check Results</b>

<b>Raw Response Type:</b> <code>{type(emails)}</code>
<b>Emails Found:</b> <code>{current_count}</code>
<b>Previous Count:</b> <code>{last_count}</code>
<b>New Emails:</b> <code>{max(0, current_count - last_count)}</code>

<b>Monitoring Active:</b> <code>{email_monitors.get(user_id, False)}</code>
<b>Session Active:</b> <code>{session.get('is_active', False)}</code>"""
        
        if emails and len(emails) > 0:
            response += f"\n\n<b>Sample Email:</b>\n<code>{str(emails[0])[:200]}...</code>"
        
        bot.reply_to(message, response, parse_mode='HTML')
        
    except Exception as e:
        logger.error(f"Force check error for user {user_id}: {e}")
        error_response = f"""❌ <b>Force Check Failed</b>

<b>Error:</b> <code>{escape_html(str(e))}</code>"""
        
        bot.reply_to(message, error_response, parse_mode='HTML')

@bot.message_handler(commands=['restart_monitoring'])
def restart_monitoring_command(message):
    user_id = message.from_user.id
    session = get_user_session(user_id)
    
    if not session.get('token'):
        bot.reply_to(message, "❌ No email token found. Generate a new identity first.", parse_mode='HTML')
        return
    
    # Restart monitoring for this user
    with session_lock:
        email_monitors[user_id] = True
        active_users.add(user_id)
        session['is_active'] = True
        session['error_count'] = 0
        session['last_activity'] = datetime.now()
    
    logger.info(f"Restarted monitoring for user {user_id}")
    
    response = f"""🔄 <b>Monitoring Restarted</b>

<b>Email:</b> <code>{session.get('email', 'Not set')}</code>
<b>Monitoring:</b> <code>Active</code>
<b>Session:</b> <code>Active</code>

<i>Email monitoring has been restarted for your account.</i>"""
    
    bot.reply_to(message, response, parse_mode='HTML')

@bot.message_handler(commands=['monitor_status'])
def monitor_status_command(message):
    user_id = message.from_user.id
    
    # Check monitoring thread status
    thread_status = "Running" if monitor_thread.is_alive() else "Stopped"
    
    # Check user monitoring status
    user_monitoring = email_monitors.get(user_id, False)
    user_active = user_id in active_users
    
    # Check message processor thread
    message_thread_status = "Running" if message_thread.is_alive() else "Stopped"
    
    response = f"""🔍 <b>Monitoring Status</b>

<b>Monitor Thread:</b> <code>{thread_status}</code>
<b>Message Thread:</b> <code>{message_thread_status}</code>
<b>Your Monitoring:</b> <code>{user_monitoring}</code>
<b>Your Active:</b> <code>{user_active}</code>
<b>Total Active Users:</b> <code>{len(active_users)}</code>
<b>Total Sessions:</b> <code>{len(user_sessions)}</code>

<i>Use /restart_monitoring if your monitoring is not active.</i>"""
    
    bot.reply_to(message, response, parse_mode='HTML')

@bot.message_handler(commands=['test_message'])
def test_message_command(message):
    user_id = message.from_user.id
    
    # Test the message queue system
    test_message = {
        'user_id': user_id,
        'text': "🧪 <b>Test Message</b>\n\nThis is a test to verify the message system is working.",
        'kwargs': {}
    }
    
    message_queue.put(test_message)
    
    response = f"""🧪 <b>Test Message Sent</b>

<b>Message:</b> <code>Queued for delivery</code>
<b>Queue Size:</b> <code>{message_queue.qsize()}</code>

<i>If you receive a test message, the system is working correctly.</i>"""
    
    bot.reply_to(message, response, parse_mode='HTML')

@bot.message_handler(commands=['api_status'])
def api_status_command(message):
    user_id = message.from_user.id
    
    tempmail = TempMailAPI()
    
    response = "🔌 <b>API Status Check</b>\n\n"
    
    for i, base_url in enumerate(tempmail.base_urls):
        try:
            # Test generate endpoint
            test_response = tempmail.generate_email()
            if test_response:
                response += f"✅ <b>Provider {i+1}:</b> <code>{base_url}</code>\n"
                response += f"   <b>Status:</b> <code>Working</code>\n"
                response += f"   <b>Sample Email:</b> <code>{test_response['address']}</code>\n\n"
            else:
                response += f"❌ <b>Provider {i+1}:</b> <code>{base_url}</code>\n"
                response += f"   <b>Status:</b> <code>Failed</code>\n\n"
        except Exception as e:
            response += f"❌ <b>Provider {i+1}:</b> <code>{base_url}</code>\n"
            response += f"   <b>Status:</b> <code>Error: {str(e)[:50]}...</code>\n\n"
    
    response += "<i>This shows the current status of all API providers.</i>"
    
    bot.reply_to(message, response, parse_mode='HTML')

@bot.message_handler(commands=['test_otp'])
def test_otp_command(message):
    user_id = message.from_user.id
    
    # Test with the specific OTP from the user's example
    test_text = "OTP: 83fa0d9cd22016e3"
    codes = extract_otp_codes(test_text)
    
    response = f"""🧪 <b>OTP Detection Test</b>

<b>Test Text:</b> <code>{test_text}</code>
<b>Detected Codes:</b> <code>{codes}</code>

<b>Test Results:</b>"""
    
    if codes and "83fa0d9cd22016e3" in codes:
        response += f"\n✅ <b>SUCCESS:</b> OTP detection is working correctly!"
    else:
        response += f"\n❌ <b>FAILED:</b> OTP detection needs fixing"
    
    response += f"\n\n<i>This tests the OTP detection with your specific example.</i>"
    
    bot.reply_to(message, response, parse_mode='HTML')

# Email monitoring with improved error handling
def email_monitor_worker():
    while True:
        try:
            # Process all active users
            active_user_list = list(active_users)
            if active_user_list:
                logger.debug(f"Monitoring {len(active_user_list)} active users")
            else:
                logger.debug("No active users to monitor")
            
            for user_id in active_user_list:
                try:
                    if not email_monitors.get(user_id, False):
                        continue
                    
                    session = get_user_session(user_id)
                    if not session.get('token') or not session.get('is_active'):
                        continue
                    
                    # Check if session is too old (more than 12 hours)
                    if session.get('created_at'):
                        age = datetime.now() - session['created_at']
                        if age.total_seconds() > 43200:  # 12 hours
                            logger.info(f"Session expired for user {user_id}, disabling monitoring")
                            email_monitors[user_id] = False
                            active_users.discard(user_id)
                            session['is_active'] = False
                            continue
                    
                    tempmail = TempMailAPI()
                    emails = tempmail.check_inbox(session['token'])
                    
                    # Ensure emails is a list and handle different response formats
                    if not isinstance(emails, list):
                        if isinstance(emails, dict):
                            # Try different possible keys
                            for key in ['emails', 'mail', 'messages', 'data']:
                                if key in emails and isinstance(emails[key], list):
                                    emails = emails[key]
                                    break
                            else:
                                emails = []
                        else:
                            emails = []
                    
                    current_count = len(emails)
                    last_count = session.get('last_email_count', 0)
                    
                    # Debug logging
                    logger.debug(f"User {user_id}: Checking inbox. Current: {current_count}, Last: {last_count}")
                    if emails:
                        logger.debug(f"User {user_id}: Sample email structure: {list(emails[0].keys()) if emails else 'No emails'}")
                    
                    if current_count > last_count:
                        new_emails = emails[last_count:]
                        logger.info(f"User {user_id}: Found {len(new_emails)} new emails (Current: {current_count}, Last: {last_count})")
                        
                        for email in new_emails:
                            try:
                                # Try multiple fields for email content
                                email_body = ""
                                for field in ['body', 'content', 'text', 'html', 'message']:
                                    if field in email and email[field]:
                                        email_body = str(email[field])
                                        break
                                
                                if not email_body:
                                    logger.warning(f"No email body found for user {user_id}")
                                    continue
                                
                                otp_codes = extract_otp_codes(email_body)
                                best_otp = max(otp_codes, key=len) if otp_codes else None
                                
                                confirm_link = extract_confirm_link(email)
                                
                                if confirm_link:
                                    content = format_new_message_with_confirm_link(email, best_otp)
                                    markup = types.InlineKeyboardMarkup()
                                    markup.add(types.InlineKeyboardButton("✅ Confirm Link", url=confirm_link))
                                    
                                    # Queue message for processing
                                    message_queue.put({
                                        'user_id': user_id,
                                        'text': content,
                                        'kwargs': {'reply_markup': markup}
                                    })
                                else:
                                    if best_otp:
                                        content = format_new_message_without_confirm_link(email, best_otp)
                                    else:
                                        content = format_new_message_without_confirm_link(email)
                                    
                                    # Queue message for processing
                                    message_queue.put({
                                        'user_id': user_id,
                                        'text': content
                                    })
                                
                                logger.info(f"Processed email for user {user_id}: {email.get('subject', 'No Subject')}")
                                
                            except Exception as e:
                                logger.error(f"Error processing email for user {user_id}: {e}")
                        
                        # Update session
                        with session_lock:
                            session['last_email_count'] = current_count
                            session['cached_emails'] = emails
                            session['last_activity'] = datetime.now()
                            session['error_count'] = 0  # Reset error count on success
                
                except Exception as e:
                    logger.error(f"Error monitoring user {user_id}: {e}")
                    session = get_user_session(user_id)
                    session['error_count'] = session.get('error_count', 0) + 1
                    
                    # Only disable monitoring after many consecutive errors
                    if session['error_count'] > 20:  # Increased threshold for better stability
                        email_monitors[user_id] = False
                        active_users.discard(user_id)
                        session['is_active'] = False
                        logger.warning(f"Disabled monitoring for user {user_id} due to {session['error_count']} consecutive errors")
                        
                        # Notify user about monitoring being disabled
                        try:
                            message_queue.put({
                                'user_id': user_id,
                                'text': "⚠️ <b>Monitoring paused</b>\n\nToo many errors. Generate a new identity to restart."
                            })
                        except:
                            pass
                    else:
                        # Wait longer on consecutive errors
                        if session['error_count'] > 8:
                            time.sleep(30)  # Wait 30 seconds on multiple errors
                        elif session['error_count'] > 3:
                            time.sleep(15)  # Wait 15 seconds on some errors
            
            time.sleep(5)  # Check every 5 seconds for better responsiveness
            
        except Exception as e:
            logger.error(f"Error in email monitor: {e}")
            time.sleep(10)

# Start monitoring thread
monitor_thread = threading.Thread(target=email_monitor_worker, daemon=True)
monitor_thread.start()

# Verify monitoring thread is running
def verify_monitoring_thread():
    """Verify that monitoring thread is running"""
    if monitor_thread.is_alive():
        logger.info("Email monitoring thread is running")
        return True
    else:
        logger.error("Email monitoring thread is NOT running!")
        return False

# Check after a short delay
def delayed_check():
    time.sleep(2)
    verify_monitoring_thread()

threading.Thread(target=delayed_check, daemon=True).start()

def main():
    print("=" * 60)
    print("VoIP Bot - Multi-User Version")
    print("=" * 60)
    print("Bot starting...")
    print("Service: https://api.tempmail.lol")
    print(f"Bot Token: {BOT_TOKEN[:20]}...")
    print("Features:")
    print("+ Multi-user support with rate limiting")
    print("+ Identity generation with auto-monitoring")
    print("+ Reply keyboard buttons")
    print("+ Confirm link detection")
    print("+ OTP extraction")
    print("+ Error handling and retry logic")
    print("Press Ctrl+C to stop")
    print("=" * 60)
    
    logger.info("Email monitor worker started")
    logger.info("Message processor started")
    
    # Clear any existing webhook and updates
    try:
        bot.remove_webhook()  # Remove webhook before polling
        requests.get(f"https://api.telegram.org/bot{BOT_TOKEN}/getUpdates?offset=-1", timeout=5)
        time.sleep(5)  # Wait for API to clear
    except Exception as e:
        logger.error(f"Error clearing webhook: {e}")
    
    logger.info("Starting bot polling...")
    
    # Retry logic for 409 conflicts
    max_retries = 5
    retry_count = 0
    
    try:
        while retry_count < max_retries:
            try:
                bot.infinity_polling(
                    skip_pending=True,
                    timeout=60, 
                    long_polling_timeout=30, 
                    none_stop=True, 
                    interval=0,
                    allowed_updates=['message', 'callback_query']
                )
                break  # If successful, exit the retry loop
            except Exception as e:
                if "409" in str(e):
                    retry_count += 1
                    logger.error(f"409 Conflict detected. Retry {retry_count}/{max_retries}")
                    if retry_count < max_retries:
                        # Clear webhook and wait longer
                        try:
                            requests.get(f"https://api.telegram.org/bot{BOT_TOKEN}/deleteWebhook", timeout=5)
                            requests.get(f"https://api.telegram.org/bot{BOT_TOKEN}/getUpdates?offset=-1", timeout=5)
                        except:
                            pass
                        time.sleep(60)  # Wait 1 minute before retry
                    else:
                        logger.error("Max retries reached. Giving up.")
                        raise
                else:
                    raise
    except KeyboardInterrupt:
        print("\n\n" + "=" * 60)
        print("Bot stopped by user")
        print("=" * 60)
    except Exception as e:
        logger.error(f"Bot error: {e}")

if __name__ == "__main__":
    main()